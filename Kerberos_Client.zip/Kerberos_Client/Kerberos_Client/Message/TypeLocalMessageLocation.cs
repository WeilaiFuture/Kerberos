﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kerberos_Client.UI
{
    public enum TypeLocalMessageLocation
    {
        chatRecv,
        chatSend
    }
}
