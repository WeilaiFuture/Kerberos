﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kerberos_Client
{
    public class Number
    {
        public Number()
        {
            Items = new List<string>
            {
                "1308531510",
                "2569875222",
                "5648999998",
                "2415645616",
            };
        }

        public List<string> Items { get; set; }
    }
}
